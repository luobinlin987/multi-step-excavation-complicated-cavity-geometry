#!/bin/bash

timer_start=`date "+%Y-%m-%d %H:%M:%S"`
echo "start_time: $timer_start"

# cd ~/research-paper/paper14/TUST/computation/codes/case1/
# echo '******fortran program of case verification starts******'
# gfortran case1.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# cd ~/research-paper/paper14/TUST/computation/codes/discussion-x0/
# gfortran x0-10-0.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# gfortran x0-10-1.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# gfortran x0-10-2.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# gfortran x0-10-3.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# gfortran x0-10-4.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case
# gfortran x0-10-5.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
# ./case

cd ~/research-paper/paper14/TUST/computation/plot/
# echo '******gnuplot starts******'
# echo '******figure 5a******'
# gnuplot cavity-boundary.gp
# cp cavity-boundary.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig5/fig5a.pdf
# echo '******figure 6******'
# gnuplot mapping-zeta-plane.gp
# cp mapping-zeta-plane.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig6.pdf
# echo '******figure 7******'
# gnuplot mapping-w-plane.gp
# cp mapping-w-plane.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig7.pdf
# echo '******figure 8******'
# gnuplot mapping-z-plane.gp
# cp mapping-z-plane.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig8.pdf
# echo '******figure 9******'
# gnuplot boundary-condition.gp
# cp boundary-condition.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig9.pdf
# echo '******figure 11******'
# gnuplot mechanical-comparison.gp
# cp mechanical-comparison.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig11.pdf
# gnuplot boundary-condition-numer.gnuplot
# cp boundary-condition-numer.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig12.pdf
gnuplot discussion-x0.gnuplot
cp discussion-x0.pdf /home/lin/research-paper/paper14/TUST/manuscript-revision/fig13.pdf


timer_end=`date "+%Y-%m-%d %H:%M:%S"`
echo "end_time: $timer_end"
start_seconds=$(date --date="$timer_start" +%s);
end_seconds=$(date --date="$timer_end" +%s);
echo "consuming_time: "$((end_seconds-start_seconds))"s"
