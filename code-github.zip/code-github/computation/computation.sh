#!/bin/bash

timer_start=`date "+%Y-%m-%d %H:%M:%S"`
echo "start_time: $timer_start"

cd /your-path/computation/codes/
echo '******fortran program starts******'
gfortran numreical-case.f90 -g -L/usr/local/lib -llapack -lrefblas -o case
./case

cd /your-path/computation/plot/
echo '******gnuplot starts******'
echo '******figure 4a******'
gnuplot cavity-boundary.gp
cp cavity-boundary.pdf /your-path/manuscript/fig4/fig4a.pdf
echo '******figure 5******'
gnuplot mapping-zeta-plane.gp
cp mapping-zeta-plane.pdf /your-path/manuscript/fig5.pdf
echo '******figure 6******'
gnuplot mapping-w-plane.gp
cp mapping-w-plane.pdf /your-path/manuscript/fig6.pdf
echo '******figure 7******'
gnuplot mapping-z-plane.gp
cp mapping-z-plane.pdf /your-path/manuscript/fig7.pdf
echo '******figure 8******'
gnuplot boundary-condition.gp
cp boundary-condition.pdf /your-path/manuscript/fig8.pdf
echo '******figure 10******'
gnuplot mechanical-comparison.gp
cp mechanical-comparison.pdf /your-path/manuscript/fig10.pdf

timer_end=`date "+%Y-%m-%d %H:%M:%S"`
echo "end_time: $timer_end"
start_seconds=$(date --date="$timer_start" +%s);
end_seconds=$(date --date="$timer_end" +%s);
echo "consuming_time: "$((end_seconds-start_seconds))"s"
